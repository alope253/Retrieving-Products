package widgetstore.web;

import desserts.*;
import candy.CandyEntity;
import hibernate.HibernateUtils;
import org.hibernate.Session;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CandyDetailsServlet extends HttpServlet {

    Session session;

    public void init() {
        session = HibernateUtils.buildSessionFactory().openSession();
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<form action='' method='POST'>");
        out.println("<label>Enter Product (Candy) ID: <input type='text' name='candy-id'></input></label>");
        out.println("<input type='submit'>Get Details</input>");
        out.println("</form>");
    }

    public void doPost(HttpServletRequest request,
          HttpServletResponse response) throws ServletException, IOException {
        String candyId = request.getParameter("candy-id");
        PrintWriter out = response.getWriter();

        CandyEntity candyEntity = session.get(
        		CandyEntity.class,
                Long.parseLong(candyId)
        );
        if (candyEntity != null) {
            out.println("Found candy: " + candyEntity.getName() + " with price: " + candyEntity.getPrice());
        } else {
            out.println("No candy found for id: " + candyId);
        }
    }

}